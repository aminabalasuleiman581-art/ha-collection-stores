import { notFound } from "next/navigation";
import { getProducts } from "@/lib/products";
import { ProductDetail } from "@/components/product-detail";
export default async function ProductPage({params}:{params:Promise<{slug:string}>}) {
 const {slug}=await params; const products=await getProducts(); const product=products.find(p=>p.slug===slug); if(!product) notFound();
 return <section className="container page-section"><ProductDetail product={product}/></section>;
}
