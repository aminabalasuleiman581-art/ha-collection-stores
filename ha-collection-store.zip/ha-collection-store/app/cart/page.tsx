 "use client";
import Link from "next/link";
import {useCart} from "@/components/cart-provider";
import {naira,WHATSAPP_NUMBER} from "@/lib/format";
export default function CartPage(){
 const {items,setQty,remove,total}=useCart();
 const orderText=encodeURIComponent("Hello H&A Collection, I would like to place this order:\n"+items.map(x=>`${x.product.name} x ${x.quantity} — ${naira(x.product.price*x.quantity)}`).join("\n")+`\nSubtotal: ${naira(total)}\nPlease confirm delivery fee and availability.`);
 return <section className="container page-section"><div className="page-intro"><span className="eyebrow">YOUR SELECTION</span><h1>Shopping bag</h1></div>{!items.length?<div className="empty-state"><p>Your cart is waiting for something lovely.</p><Link className="button button-dark" href="/shop">Explore the shop</Link></div>:<div className="cart-layout"><div>{items.map(x=><div className="cart-row" key={x.product.id}><img src={x.product.image_url} alt=""/><div className="cart-item-info"><b>{x.product.name}</b><span>{naira(x.product.price)}</span><div className="quantity"><button onClick={()=>setQty(x.product.id,x.quantity-1)}>−</button><span>{x.quantity}</span><button onClick={()=>setQty(x.product.id,x.quantity+1)}>+</button></div></div><button className="remove" onClick={()=>remove(x.product.id)}>Remove</button></div>)}</div><aside className="summary"><h2>Order summary</h2><div><span>Subtotal</span><b>{naira(total)}</b></div><p>Delivery fee will be confirmed based on your location.</p><a className="button button-dark full" target="_blank" rel="noreferrer" href={`https://wa.me/${WHATSAPP_NUMBER}?text=${orderText}`}>Continue order on WhatsApp</a><Link href="/shop" className="text-link">Continue shopping</Link></aside></div>}</section>;
}
