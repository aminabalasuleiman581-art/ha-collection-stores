import { getProducts } from "@/lib/products";
import { ShopClient } from "@/components/shop-client";
export default async function Shop(){const products=await getProducts();return <section className="container page-section"><div className="page-intro"><span className="eyebrow">THE H&A EDIT</span><h1>Shop the collection</h1><p>Explore handmade bags and beautiful pieces for your home.</p></div><ShopClient products={products}/></section>}
